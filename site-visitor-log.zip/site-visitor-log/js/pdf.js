/* pdf.js — a small, dependency-free PDF writer.
   Why hand-rolled: the app must generate PDFs fully offline, on the very
   first launch, with no CDN library fetch. This writes valid PDF 1.7 byte
   streams directly (objects, xref table, trailer) using only the standard
   14 fonts (Helvetica-Bold / Courier / Courier-Bold), so no font embedding
   is needed either.

   Supports a genuine "invisible" text render mode (PDF text rendering
   mode 3 — the same mechanism used for the hidden OCR text layer under a
   scanned page) so machine-readable data can be embedded in a page
   without being visible, while still being extractable by copying text
   or running text-extraction tools.

   Works in the browser AND under Node (for testing) — see the
   module.exports guard at the bottom.
*/
(function (global) {
  const PAGE_W = 595.28; // A4 pt
  const PAGE_H = 841.89;

  function sanitizeAscii(str) {
    return String(str == null ? '' : str)
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')   // strip accents -> plain letters
      .replace(/[^\x20-\x7E]/g, '?');    // anything else -> '?'
  }

  function pdfEscape(str) {
    return sanitizeAscii(str)
      .replace(/\\/g, '\\\\')
      .replace(/\(/g, '\\(')
      .replace(/\)/g, '\\)')
      .replace(/[\r\n]/g, ' ');
  }

  function truncate(str, maxChars) {
    const s = sanitizeAscii(str);
    if (s.length <= maxChars) return s;
    if (maxChars <= 1) return s.slice(0, maxChars);
    return s.slice(0, maxChars - 1) + '.';
  }

  class SimplePDF {
    constructor() {
      this.W = PAGE_W;
      this.H = PAGE_H;
      this.objects = [];      // body strings, 1-indexed via array position
      this.pageObjNums = [];
      this._ops = [];
      this._pageStarted = false;

      this._pagesSlot = this._reserve();
      this.catalogObjNum = this._newObj(`<< /Type /Catalog /Pages ${this._pagesSlot} 0 R >>`);
      this.F1 = this._newObj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
      this.F2 = this._newObj('<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>');
      this.F3 = this._newObj('<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>');
    }

    _reserve() { this.objects.push(null); return this.objects.length; }
    _newObj(body) { this.objects.push(body); return this.objects.length; }
    _setObj(n, body) { this.objects[n - 1] = body; }

    // Start a fresh page. Safe to call even before any drawing (first
    // page is implicit — it starts as soon as you draw anything).
    newPage() {
      this._flushPage();
      this._ops = [];
      this._pageStarted = true;
    }

    _flushPage() {
      if (!this._pageStarted && this.pageObjNums.length > 0) return;
      const content = this._ops.join('\n');
      const contentObj = this._newObj(`<< /Length ${byteLen(content)} >>\nstream\n${content}\nendstream`);
      const pageObj = this._newObj(
        `<< /Type /Page /Parent ${this._pagesSlot} 0 R /MediaBox [0 0 ${this.W} ${this.H}] ` +
        `/Resources << /Font << /F1 ${this.F1} 0 R /F2 ${this.F2} 0 R /F3 ${this.F3} 0 R >> >> ` +
        `/Contents ${contentObj} 0 R >>`
      );
      this.pageObjNums.push(pageObj);
      this._pageStarted = false;
    }

    text(x, y, str, opts) {
      opts = opts || {};
      const font = opts.font || 'F2';
      const size = opts.size || 8;
      const tr = opts.invisible ? 3 : 0;
      this._pageStarted = true;
      this._ops.push(
        `BT /${font} ${size} Tf ${tr} Tr 1 0 0 1 ${num(x)} ${num(y)} Tm (${pdfEscape(str)}) Tj ET`
      );
    }

    line(x1, y1, x2, y2, opts) {
      opts = opts || {};
      const w = opts.width || 0.5;
      const gray = opts.gray != null ? opts.gray : 0;
      this._pageStarted = true;
      this._ops.push(`${gray} G ${w} w ${num(x1)} ${num(y1)} m ${num(x2)} ${num(y2)} l S`);
    }

    rect(x, y, w, h, opts) {
      opts = opts || {};
      this._pageStarted = true;
      if (opts.fillGray != null) {
        this._ops.push(`${opts.fillGray} g ${num(x)} ${num(y)} ${num(w)} ${num(h)} re f`);
      } else {
        this._ops.push(`${num(x)} ${num(y)} ${num(w)} ${num(h)} re S`);
      }
    }

    finalize() {
      this._flushPage();
      this._setObj(
        this._pagesSlot,
        `<< /Type /Pages /Kids [${this.pageObjNums.map(n => n + ' 0 R').join(' ')}] /Count ${this.pageObjNums.length} >>`
      );
    }

    // Returns a Uint8Array of the complete PDF file.
    outputBytes() {
      this.finalize();
      const enc = (typeof TextEncoder !== 'undefined') ? new TextEncoder() : null;
      const encode = (s) => enc ? enc.encode(s) : Buffer.from(s, 'utf-8');

      let out = '';
      let bLen = 0;
      const append = (s) => { out += s; bLen += encode(s).length; };

      append('%PDF-1.7\n');
      const offsets = [0];
      for (let i = 0; i < this.objects.length; i++) {
        offsets.push(bLen);
        append(`${i + 1} 0 obj\n${this.objects[i]}\nendobj\n`);
      }
      const xrefOffset = bLen;
      append(`xref\n0 ${this.objects.length + 1}\n0000000000 65535 f \n`);
      for (let i = 1; i <= this.objects.length; i++) {
        append(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
      }
      append(`trailer\n<< /Size ${this.objects.length + 1} /Root ${this.catalogObjNum} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);

      return encode(out);
    }

    outputBlob() {
      return new Blob([this.outputBytes()], { type: 'application/pdf' });
    }
  }

  function num(n) { return (Math.round(n * 100) / 100).toString(); }
  function byteLen(s) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(s).length;
    return Buffer.byteLength(s, 'utf-8');
  }

  // ---- Invisible data-layer embedding -------------------------------
  // Appends one or more pages whose only visible content is a small
  // caption; the rest of the page is real PDF text drawn in render
  // mode 3 (invisible) carrying a JSON payload between marker strings.
  function embedInvisibleData(doc, dataObj) {
    const json = JSON.stringify(dataObj);
    const payload = '%%VISITORLOG-DATA-START%%' + json + '%%VISITORLOG-DATA-END%%';
    const safe = sanitizeAscii(payload);
    const chunkSize = 150;
    const chunks = [];
    for (let i = 0; i < safe.length; i += chunkSize) chunks.push(safe.slice(i, i + chunkSize));

    const margin = 40;
    const top = doc.H - 50;
    const bottom = 40;
    const lineHeight = 9;

    doc.newPage();
    doc.text(margin, top, 'Embedded backup data (machine-readable; not for printing).', { font: 'F2', size: 7 });
    doc.line(margin, top - 8, doc.W - margin, top - 8, { width: 0.5, gray: 0.7 });
    let y = top - 24;
    for (const chunk of chunks) {
      if (y < bottom) {
        doc.newPage();
        doc.text(margin, top, 'Embedded backup data (continued).', { font: 'F2', size: 7 });
        doc.line(margin, top - 8, doc.W - margin, top - 8, { width: 0.5, gray: 0.7 });
        y = top - 24;
      }
      doc.text(margin, y, chunk, { font: 'F2', size: 6, invisible: true });
      y -= lineHeight;
    }
  }

  const PDFLib = { SimplePDF, pdfEscape, sanitizeAscii, truncate, embedInvisibleData };
  global.PDFLib = PDFLib;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = PDFLib;
  }
})(typeof window !== 'undefined' ? window : globalThis);
