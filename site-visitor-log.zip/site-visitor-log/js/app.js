/* app.js — UI, state and wiring for the Site Visitor Log.
   Depends on DB (db.js) and PDFLib (pdf.js), both loaded before this file. */
(function () {
  'use strict';

  // ---------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------
  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function todayISO() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function nowTimeHHMM() {
    const d = new Date();
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }
  function fmtDateHuman(d) {
    if (!(d instanceof Date)) d = new Date(d);
    return d.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
  }
  function parseVehicles(str) {
    return String(str || '').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
  }
  function debounce(fn, ms) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }
  function emptyState(title, sub) {
    return `<div class="empty-state"><span class="eyebrow">${escapeHtml(title)}</span><p>${escapeHtml(sub)}</p></div>`;
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  // ---------------------------------------------------------------
  // Toast
  // ---------------------------------------------------------------
  function toast(msg, opts) {
    opts = opts || {};
    const container = document.getElementById('toast-container');
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<span>${escapeHtml(msg)}</span><span class="actions"></span>`;
    const actionsEl = el.querySelector('.actions');
    if (opts.actionLabel) {
      const btn = document.createElement('button');
      btn.className = 'primary';
      btn.textContent = opts.actionLabel;
      btn.onclick = () => { el.remove(); opts.onAction && opts.onAction(); };
      actionsEl.appendChild(btn);
    }
    const dismiss = document.createElement('button');
    dismiss.textContent = opts.actionLabel ? 'Dismiss' : 'OK';
    dismiss.onclick = () => el.remove();
    actionsEl.appendChild(dismiss);
    container.appendChild(el);
    setTimeout(() => { if (el.parentNode) el.remove(); }, opts.actionLabel ? 12000 : 4000);
  }

  // ---------------------------------------------------------------
  // Modal
  // ---------------------------------------------------------------
  function openModal(innerHtml) {
    const root = document.getElementById('modal-root');
    root.innerHTML = `<div class="modal-overlay" id="modal-overlay"><div class="modal">${innerHtml}</div></div>`;
    const overlay = document.getElementById('modal-overlay');
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
    root.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', closeModal));
    return root.querySelector('.modal');
  }
  function closeModal() { document.getElementById('modal-root').innerHTML = ''; }

  // ---------------------------------------------------------------
  // State
  // ---------------------------------------------------------------
  const state = {
    view: 'tracker',
    activeSheetId: null,
    directory: [],
    settings: { siteName: '', inductionValidityMonths: 12, expiryWarningDays: 30 },
    logFilter: 'all',
    entryType: 'general'
  };

  async function loadSettings() {
    const rows = await DB.getAll('settings');
    const map = {};
    rows.forEach(r => map[r.key] = r.value);
    state.settings = {
      siteName: map.siteName || '',
      inductionValidityMonths: map.inductionValidityMonths != null ? map.inductionValidityMonths : 12,
      expiryWarningDays: map.expiryWarningDays != null ? map.expiryWarningDays : 30
    };
  }
  async function saveSetting(key, value) { await DB.put('settings', { key, value }); }
  function updateHeaderSiteName() {
    document.getElementById('site-name-sub').textContent = state.settings.siteName || 'Occurrence & induction tracker';
  }

  // ---------------------------------------------------------------
  // Induction status: green (valid) / gold (expiring soon) / red (needed / expired)
  // ---------------------------------------------------------------
  function computeStatus(item) {
    if (!item.inductionDate) return { level: 'red', label: 'Induction needed', expiry: null };
    const months = state.settings.inductionValidityMonths || 12;
    const start = new Date(item.inductionDate + 'T00:00:00');
    const expiry = new Date(start.getFullYear(), start.getMonth() + months, start.getDate());
    const now = new Date();
    const daysLeft = Math.floor((expiry - now) / 86400000);
    const warnDays = state.settings.expiryWarningDays != null ? state.settings.expiryWarningDays : 30;
    if (daysLeft < 0) return { level: 'red', label: 'Induction expired', expiry };
    if (daysLeft <= warnDays) return { level: 'gold', label: `Expires in ${daysLeft}d`, expiry };
    return { level: 'green', label: `Valid to ${fmtDateHuman(expiry)}`, expiry };
  }

  // ---------------------------------------------------------------
  // Directory (contractors + recognised visitors share one store)
  // ---------------------------------------------------------------
  async function refreshDirectory() { state.directory = await DB.getAll('directory'); }
  function findDirectoryByName(name) {
    const n = name.trim().toLowerCase();
    return state.directory.find(d => d.name.trim().toLowerCase() === n) || null;
  }
  // Retroactively link a just-logged entry to a directory record created
  // *after* it (e.g. via the "add to archive" toast), so the visit that
  // revealed a missing induction still shows up in that contractor's
  // visit history and status dot.
  async function linkEntryToDirectory(entryId, directoryId) {
    if (!entryId) return;
    const e = await DB.get('entries', entryId);
    if (e) { e.directoryId = directoryId; await DB.put('entries', e); }
  }

  // ---------------------------------------------------------------
  // Sheets (the settable start/end "tracker sheet" period)
  // ---------------------------------------------------------------
  async function ensureTodaySheet() {
    const sheets = await DB.getAll('sheets');
    const today = todayISO();
    let todaySheet = sheets.find(s => s.date === today);
    if (!todaySheet) {
      sheets.sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
      const last = sheets[0];
      todaySheet = {
        id: uid(), date: today,
        startTime: last ? last.startTime : '05:00',
        endTime: last ? last.endTime : '13:00',
        label: last ? last.label : '',
        createdAt: new Date().toISOString()
      };
      await DB.put('sheets', todaySheet);
      sheets.unshift(todaySheet);
    }
    if (!state.activeSheetId || !sheets.find(s => s.id === state.activeSheetId)) {
      state.activeSheetId = todaySheet.id;
    }
  }
  async function populateSheetSelect() {
    const sheets = (await DB.getAll('sheets')).sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
    const sel = document.getElementById('sheet-select');
    sel.innerHTML = sheets.map(s =>
      `<option value="${s.id}" ${s.id === state.activeSheetId ? 'selected' : ''}>${s.date} \u00b7 ${s.startTime}-${s.endTime}${s.label ? ' (' + escapeHtml(s.label) + ')' : ''}</option>`
    ).join('');
  }
  function openSheetPeriodModal(existing) {
    const isNew = !existing;
    const base = existing || { id: uid(), date: todayISO(), startTime: '05:00', endTime: '13:00', label: '' };
    const html = `
      <button class="modal-close" data-close>&times;</button>
      <h2>${isNew ? 'New sheet' : 'Edit shift period'}</h2>
      <div class="field"><label>Date</label><input type="date" id="sp-date" value="${base.date}"></div>
      <div class="row2">
        <div class="field"><label>Start</label><input type="time" id="sp-start" value="${base.startTime}"></div>
        <div class="field"><label>End</label><input type="time" id="sp-end" value="${base.endTime}"></div>
      </div>
      <div class="field ui-text"><label>Label (optional)</label><input type="text" id="sp-label" value="${escapeHtml(base.label || '')}" placeholder="e.g. Day shift, Night shift"></div>
      <button class="btn btn-primary" id="sp-save">${isNew ? 'Create sheet' : 'Save period'}</button>`;
    const root = openModal(html);
    root.querySelector('#sp-save').addEventListener('click', async () => {
      base.date = root.querySelector('#sp-date').value || todayISO();
      base.startTime = root.querySelector('#sp-start').value || '00:00';
      base.endTime = root.querySelector('#sp-end').value || '23:59';
      base.label = root.querySelector('#sp-label').value.trim();
      if (isNew) base.createdAt = new Date().toISOString();
      await DB.put('sheets', base);
      state.activeSheetId = base.id;
      closeModal();
      await renderTracker();
      toast(isNew ? 'New sheet created.' : 'Shift period updated.');
    });
  }

  // ---------------------------------------------------------------
  // Navigation
  // ---------------------------------------------------------------
  function switchView(view) {
    state.view = view;
    document.querySelectorAll('.view').forEach(v => v.hidden = true);
    document.getElementById('view-' + view).hidden = false;
    document.querySelectorAll('.tabbar button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    renderCurrentView();
  }
  function renderCurrentView() {
    if (state.view === 'tracker') renderTracker();
    else if (state.view === 'contractors') renderContractors();
    else if (state.view === 'visitors') renderVisitors();
    else if (state.view === 'export') renderExport();
  }

  // ---------------------------------------------------------------
  // Tracker view
  // ---------------------------------------------------------------
  async function renderTracker() {
    await ensureTodaySheet();
    await populateSheetSelect();
    await refreshDirectory();
    const sheet = await DB.get('sheets', state.activeSheetId);
    if (!sheet) return;

    let entries = await DB.getAllByIndex('entries', 'sheetId', sheet.id);
    entries.sort((a, b) => (b.timeIn || '').localeCompare(a.timeIn || ''));

    const onSite = entries.filter(e => !e.timeOut).length;
    const contractorCount = entries.filter(e => e.type === 'contractor').length;
    document.getElementById('tracker-summary').innerHTML = `
      <div class="stat"><b>${entries.length}</b><span>Total today</span></div>
      <div class="stat"><b style="color:var(--gold)">${onSite}</b><span>On site</span></div>
      <div class="stat"><b style="color:var(--accent)">${contractorCount}</b><span>Contractors</span></div>`;

    const contacts = [...new Set(entries.map(e => e.siteContact).filter(Boolean))].slice(0, 15);
    document.getElementById('contact-history').innerHTML = contacts.map(c => `<option value="${escapeHtml(c)}">`).join('');

    const filter = state.logFilter;
    const q = (document.getElementById('log-search').value || '').toLowerCase();
    let shown = entries;
    if (filter === 'general') shown = shown.filter(e => e.type === 'general');
    else if (filter === 'contractor') shown = shown.filter(e => e.type === 'contractor');
    else if (filter === 'onsite') shown = shown.filter(e => !e.timeOut);
    if (q) shown = shown.filter(e => (e.name + ' ' + e.vehicle + ' ' + e.reason).toLowerCase().includes(q));

    const list = document.getElementById('entries-list');
    if (!shown.length) {
      list.innerHTML = emptyState('No entries', entries.length ? 'No entries match your filter.' : 'Log the first visitor for this sheet above.');
      return;
    }
    const dirById = {}; state.directory.forEach(d => dirById[d.id] = d);
    list.innerHTML = shown.map(entry => renderEntryRow(entry, dirById)).join('');
  }

  function renderEntryRow(entry, dirById) {
    const dirItem = entry.directoryId ? dirById[entry.directoryId] : null;
    const statusDot = (entry.type === 'contractor' && dirItem) ? `<span class="dot dot-${computeStatus(dirItem).level}"></span>` : '';
    return `
    <div class="log-row type-${entry.type} ${!entry.timeOut ? 'onsite' : ''}" data-id="${entry.id}">
      <div class="times"><b>${entry.timeIn || '\u2014'}</b>${entry.timeOut ? entry.timeOut : 'On site'}</div>
      <div class="main">
        <div class="name-line"><span class="nm">${escapeHtml(entry.name)}</span>${statusDot}</div>
        <div class="meta">${escapeHtml(entry.vehicle) || '\u2014'} \u00b7 <span class="badge ${entry.type === 'contractor' ? 'type-contractor' : ''}">${entry.type === 'contractor' ? 'Contractor' : 'General'}</span></div>
        <div class="reason">${escapeHtml(entry.reason)}</div>
        ${entry.siteContact ? `<div class="contact">Contact: ${escapeHtml(entry.siteContact)}</div>` : ''}
      </div>
      <div class="actions">
        ${!entry.timeOut ? `<button data-action="signout" data-id="${entry.id}" class="sign-out">Sign out</button>` : ''}
        <button data-action="edit" data-id="${entry.id}">Edit</button>
      </div>
    </div>`;
  }

  function setEntryType(type) {
    state.entryType = type;
    document.querySelectorAll('#type-toggle button').forEach(b => b.classList.toggle('active', b.dataset.type === type));
    document.getElementById('field-site-contact').style.display = type === 'contractor' ? '' : 'none';
    document.getElementById('f-sitecontact').required = type === 'contractor';
  }

  function resetEntryForm() {
    document.getElementById('entry-form').reset();
    document.getElementById('f-timein').value = nowTimeHHMM();
    document.getElementById('form-error').style.display = 'none';
    document.getElementById('ac-list').hidden = true;
    setEntryType(state.entryType);
  }

  function setupAutocomplete() {
    const input = document.getElementById('f-name');
    const list = document.getElementById('ac-list');
    input.addEventListener('input', () => {
      const q = input.value.trim().toLowerCase();
      if (!q) { list.hidden = true; list.innerHTML = ''; return; }
      const matches = state.directory.filter(d => d.name.toLowerCase().includes(q)).slice(0, 6);
      if (!matches.length) { list.innerHTML = `<div class="ac-empty">No match \u2014 will be logged as a new name.</div>`; list.hidden = false; return; }
      let rows = '';
      matches.forEach(item => {
        const vehicles = (item.vehicles && item.vehicles.length) ? item.vehicles : [''];
        const dot = item.isContractor ? `<span class="dot dot-${computeStatus(item).level}" style="margin-right:5px;"></span>` : '';
        vehicles.slice(0, 4).forEach(v => {
          rows += `<div class="ac-item" data-id="${item.id}" data-vehicle="${escapeHtml(v)}">
            <span class="ac-name">${dot}${escapeHtml(item.name)}</span>
            <span class="ac-veh">${escapeHtml(v) || '\u2014'}</span>
          </div>`;
        });
      });
      list.innerHTML = rows;
      list.hidden = false;
    });
    list.addEventListener('click', (e) => {
      const row = e.target.closest('.ac-item[data-id]');
      if (!row) return;
      const item = state.directory.find(d => d.id === row.dataset.id);
      if (item) {
        input.value = item.name;
        document.getElementById('f-vehicle').value = row.dataset.vehicle || '';
      }
      list.hidden = true; list.innerHTML = '';
    });
    document.addEventListener('click', (e) => {
      if (e.target !== input && !list.contains(e.target)) list.hidden = true;
    });
    input.addEventListener('focus', () => { if (input.value.trim()) input.dispatchEvent(new Event('input')); });
  }

  async function handleEntrySubmit(e) {
    e.preventDefault();
    const errorEl = document.getElementById('form-error');
    errorEl.style.display = 'none';
    const type = state.entryType;
    const name = document.getElementById('f-name').value.trim();
    const vehicle = document.getElementById('f-vehicle').value.trim().toUpperCase();
    const reason = document.getElementById('f-reason').value.trim();
    const siteContact = type === 'contractor' ? document.getElementById('f-sitecontact').value.trim() : '';
    const timeIn = document.getElementById('f-timein').value || nowTimeHHMM();

    if (!name || !reason || (type === 'contractor' && !siteContact)) {
      errorEl.textContent = type === 'contractor'
        ? 'Company/representative, reason, and site contact are required.'
        : 'Company/representative and reason are required.';
      errorEl.style.display = 'block';
      return;
    }

    const matched = findDirectoryByName(name);
    const entry = {
      id: uid(), sheetId: state.activeSheetId, type, name, vehicle, reason, siteContact,
      timeIn, timeOut: null, directoryId: matched ? matched.id : null,
      createdAt: new Date().toISOString()
    };
    await DB.put('entries', entry);

    if (matched && vehicle && !(matched.vehicles || []).includes(vehicle)) {
      matched.vehicles = [...(matched.vehicles || []), vehicle];
      matched.updatedAt = new Date().toISOString();
      await DB.put('directory', matched);
      await refreshDirectory();
    }

    resetEntryForm();
    await renderTracker();

    if (!matched) {
      if (type === 'contractor') {
        toast(`"${name}" isn't in the contractor archive yet.`, {
          actionLabel: 'Add to archive',
          onAction: () => openContractorModal(null, { name, vehicle, linkEntryId: entry.id })
        });
      } else {
        toast(`Save "${name}" as a recognised visitor for quicker entry next time?`, {
          actionLabel: 'Save',
          onAction: async () => {
            const newItem = {
              id: uid(), name, vehicles: vehicle ? [vehicle] : [], isContractor: false,
              inductionDate: null, notes: '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
            };
            await DB.put('directory', newItem);
            await linkEntryToDirectory(entry.id, newItem.id);
            await refreshDirectory();
            if (state.view === 'tracker') await renderTracker();
            toast(`Saved "${name}" to recognised visitors.`);
          }
        });
      }
    }
  }

  async function openEditEntryModal(id) {
    const entry = await DB.get('entries', id);
    if (!entry) return;
    const html = `
      <button class="modal-close" data-close>&times;</button>
      <h2>Edit entry</h2>
      <div class="field">
        <label>Entry type</label>
        <div class="segmented">
          <button type="button" class="edit-type ${entry.type === 'general' ? 'active type-general' : ''}" data-val="general">General</button>
          <button type="button" class="edit-type ${entry.type === 'contractor' ? 'active type-contractor' : ''}" data-val="contractor">Contractor</button>
        </div>
      </div>
      <div class="field ui-text"><label>Company / representative</label><input type="text" id="em-name" value="${escapeHtml(entry.name)}"></div>
      <div class="row2">
        <div class="field"><label>Vehicle reg</label><input type="text" id="em-vehicle" value="${escapeHtml(entry.vehicle || '')}"></div>
        <div class="field"><label>Time in</label><input type="time" id="em-timein" value="${entry.timeIn || ''}"></div>
      </div>
      <div class="field ui-text"><label>Reason</label><input type="text" id="em-reason" value="${escapeHtml(entry.reason)}"></div>
      <div class="row2">
        <div class="field"><label>Time out</label><input type="time" id="em-timeout" value="${entry.timeOut || ''}"></div>
        <div class="field ui-text" id="em-contact-wrap" style="${entry.type === 'contractor' ? '' : 'display:none;'}"><label>Site contact</label><input type="text" id="em-contact" value="${escapeHtml(entry.siteContact || '')}"></div>
      </div>
      <div class="error-text" id="em-error" style="display:none;"></div>
      <div class="btn-block-row" style="margin-top:8px;">
        <button class="btn btn-outline" id="em-delete">Delete</button>
        <button class="btn btn-primary" id="em-save">Save changes</button>
      </div>`;
    const root = openModal(html);
    let curType = entry.type;
    root.querySelectorAll('.edit-type').forEach(b => b.addEventListener('click', () => {
      curType = b.dataset.val;
      root.querySelectorAll('.edit-type').forEach(x => x.classList.remove('active', 'type-general', 'type-contractor'));
      b.classList.add('active', curType === 'general' ? 'type-general' : 'type-contractor');
      root.querySelector('#em-contact-wrap').style.display = curType === 'contractor' ? '' : 'none';
    }));
    root.querySelector('#em-save').addEventListener('click', async () => {
      const name = root.querySelector('#em-name').value.trim();
      const reason = root.querySelector('#em-reason').value.trim();
      if (!name || !reason) {
        const err = root.querySelector('#em-error');
        err.textContent = 'Company/representative and reason are required.';
        err.style.display = 'block';
        return;
      }
      entry.type = curType;
      entry.name = name;
      entry.vehicle = root.querySelector('#em-vehicle').value.trim().toUpperCase();
      entry.reason = reason;
      entry.timeIn = root.querySelector('#em-timein').value;
      entry.timeOut = root.querySelector('#em-timeout').value || null;
      entry.siteContact = curType === 'contractor' ? root.querySelector('#em-contact').value.trim() : '';
      await DB.put('entries', entry);
      closeModal();
      await renderTracker();
      toast('Entry updated.');
    });
    root.querySelector('#em-delete').addEventListener('click', async () => {
      if (!confirm('Delete this log entry? This cannot be undone.')) return;
      await DB.delete('entries', entry.id);
      closeModal();
      await renderTracker();
      toast('Entry deleted.');
    });
  }

  // ---------------------------------------------------------------
  // Contractors view
  // ---------------------------------------------------------------
  async function renderContractors() {
    await refreshDirectory();
    const search = (document.getElementById('contractor-search').value || '').toLowerCase();
    const all = state.directory.filter(d => d.isContractor);
    let green = 0, gold = 0, red = 0;
    all.forEach(d => { const s = computeStatus(d).level; if (s === 'green') green++; else if (s === 'gold') gold++; else red++; });
    document.getElementById('contractor-summary').innerHTML = `
      <div class="stat"><b style="color:var(--green)">${green}</b><span>Valid</span></div>
      <div class="stat"><b style="color:var(--gold)">${gold}</b><span>Expiring</span></div>
      <div class="stat"><b style="color:var(--red)">${red}</b><span>Needed</span></div>`;

    const items = all.filter(d => d.name.toLowerCase().includes(search)).sort((a, b) => a.name.localeCompare(b.name));
    const list = document.getElementById('contractors-list');
    if (!items.length) { list.innerHTML = emptyState('No contractors', 'Add a contractor to start tracking their induction.'); return; }
    list.innerHTML = items.map(item => {
      const st = computeStatus(item);
      return `<div class="dir-row st-${st.level}" data-id="${item.id}">
        <div class="main">
          <div class="name-line">${escapeHtml(item.name)}</div>
          <div class="sub">${escapeHtml((item.vehicles || []).join(', ')) || 'No vehicle on file'}</div>
        </div>
        <span class="status-pill st-${st.level}"><span class="dot dot-${st.level}"></span>${escapeHtml(st.label)}</span>
        <span class="chev">\u203a</span>
      </div>`;
    }).join('');
  }

  function openContractorModal(existing, prefill) {
    const isNew = !existing;
    const item = existing || {
      id: uid(), name: (prefill && prefill.name) || '', vehicles: (prefill && prefill.vehicle) ? [prefill.vehicle] : [],
      isContractor: true, inductionDate: '', notes: ''
    };
    const st = !isNew ? computeStatus(item) : null;
    const html = `
      <button class="modal-close" data-close>&times;</button>
      <h2>${isNew ? 'Add contractor' : 'Edit contractor'}</h2>
      ${st ? `<div style="margin-bottom:12px;"><span class="status-pill st-${st.level}"><span class="dot dot-${st.level}"></span>${escapeHtml(st.label)}</span></div>` : ''}
      <div class="field ui-text"><label>Contractor / company name</label><input type="text" id="cm-name" value="${escapeHtml(item.name)}"></div>
      <div class="field"><label>Vehicle registration(s)</label><input type="text" id="cm-vehicles" value="${escapeHtml((item.vehicles || []).join(', '))}" placeholder="Separate multiple with a comma"></div>
      <div class="field"><label>Last induction date</label><input type="date" id="cm-induction" value="${item.inductionDate || ''}"></div>
      <div class="field ui-text"><label>Notes</label><textarea id="cm-notes" rows="2" style="width:100%;background:var(--panel-2);border:1px solid var(--line);color:var(--paper);border-radius:6px;padding:10px;font-size:14px;">${escapeHtml(item.notes || '')}</textarea></div>
      <div class="error-text" id="cm-error" style="display:none;"></div>
      <div class="btn-block-row" style="margin-top:6px;">
        ${!isNew ? `<button class="btn btn-outline" id="cm-delete">Delete</button>` : ''}
        <button class="btn btn-primary" id="cm-save">${isNew ? 'Add contractor' : 'Save changes'}</button>
      </div>
      ${!isNew ? `<button class="btn btn-outline" id="cm-renew" style="margin-top:8px;">Mark induction completed today</button>
      <button class="btn btn-outline" id="cm-history" style="margin-top:8px;">View visit history</button>` : ''}`;
    const root = openModal(html);
    root.querySelector('#cm-save').addEventListener('click', async () => {
      const name = root.querySelector('#cm-name').value.trim();
      if (!name) {
        const err = root.querySelector('#cm-error');
        err.textContent = 'Name is required.'; err.style.display = 'block';
        return;
      }
      item.name = name;
      item.vehicles = parseVehicles(root.querySelector('#cm-vehicles').value);
      item.inductionDate = root.querySelector('#cm-induction').value || null;
      item.notes = root.querySelector('#cm-notes').value.trim();
      item.isContractor = true;
      item.updatedAt = new Date().toISOString();
      if (isNew) item.createdAt = new Date().toISOString();
      await DB.put('directory', item);
      if (isNew && prefill && prefill.linkEntryId) await linkEntryToDirectory(prefill.linkEntryId, item.id);
      await refreshDirectory();
      closeModal();
      renderCurrentView();
      toast(isNew ? `Added "${name}" to the contractor archive.` : 'Contractor updated.');
    });
    if (!isNew) {
      root.querySelector('#cm-delete').addEventListener('click', async () => {
        if (!confirm(`Remove "${item.name}" from the contractor archive? Past log entries are kept.`)) return;
        await DB.delete('directory', item.id);
        await refreshDirectory();
        closeModal();
        renderCurrentView();
        toast('Contractor removed.');
      });
      root.querySelector('#cm-renew').addEventListener('click', async () => {
        item.inductionDate = todayISO();
        item.updatedAt = new Date().toISOString();
        await DB.put('directory', item);
        await refreshDirectory();
        closeModal();
        renderCurrentView();
        toast(`Induction renewed for "${item.name}".`);
      });
      root.querySelector('#cm-history').addEventListener('click', () => { closeModal(); openVisitHistoryModal(item); });
    }
  }

  async function openVisitHistoryModal(item) {
    const entries = await DB.getAllByIndex('entries', 'directoryId', item.id);
    const sheets = await DB.getAll('sheets');
    const sheetMap = {}; sheets.forEach(s => sheetMap[s.id] = s);
    entries.sort((a, b) => {
      const da = (sheetMap[a.sheetId] ? sheetMap[a.sheetId].date : '') + (a.timeIn || '');
      const db_ = (sheetMap[b.sheetId] ? sheetMap[b.sheetId].date : '') + (b.timeIn || '');
      return db_.localeCompare(da);
    });
    const rows = entries.map(e => {
      const sh = sheetMap[e.sheetId];
      return `<div class="vh-item">
        <div class="vh-top"><span>${sh ? escapeHtml(sh.date) : ''}</span><span>${e.timeIn || ''}\u2013${e.timeOut || '\u2014'}</span></div>
        <div>${escapeHtml(e.vehicle) || 'No vehicle'} \u00b7 ${escapeHtml(e.reason)}</div>
        ${e.siteContact ? `<div style="color:var(--muted-2);">Contact: ${escapeHtml(e.siteContact)}</div>` : ''}
      </div>`;
    }).join('') || `<p style="color:var(--muted-2);font-size:13px;">No visits logged yet.</p>`;
    openModal(`<button class="modal-close" data-close>&times;</button><h2>${escapeHtml(item.name)} \u2014 visit history</h2>${rows}`);
  }

  // ---------------------------------------------------------------
  // Visitors view (recognised, non-contractor directory entries)
  // ---------------------------------------------------------------
  async function renderVisitors() {
    await refreshDirectory();
    const search = (document.getElementById('visitor-search').value || '').toLowerCase();
    const items = state.directory.filter(d => !d.isContractor && d.name.toLowerCase().includes(search)).sort((a, b) => a.name.localeCompare(b.name));
    const list = document.getElementById('visitors-list');
    if (!items.length) { list.innerHTML = emptyState('No recognised visitors', 'Add a regular visitor (e.g. a delivery driver) for one-tap entry.'); return; }
    list.innerHTML = items.map(item => `
      <div class="dir-row" data-id="${item.id}">
        <div class="main">
          <div class="name-line">${escapeHtml(item.name)}</div>
          <div class="sub">${escapeHtml((item.vehicles || []).join(', ')) || 'No vehicle on file'}</div>
        </div>
        <span class="chev">\u203a</span>
      </div>`).join('');
  }

  function openVisitorModal(existing, prefill) {
    const isNew = !existing;
    const item = existing || {
      id: uid(), name: (prefill && prefill.name) || '', vehicles: (prefill && prefill.vehicle) ? [prefill.vehicle] : [],
      isContractor: false, inductionDate: null, notes: ''
    };
    const html = `
      <button class="modal-close" data-close>&times;</button>
      <h2>${isNew ? 'Add recognised visitor' : 'Edit visitor'}</h2>
      <div class="field ui-text"><label>Name / company</label><input type="text" id="vm-name" value="${escapeHtml(item.name)}"></div>
      <div class="field"><label>Vehicle registration(s)</label><input type="text" id="vm-vehicles" value="${escapeHtml((item.vehicles || []).join(', '))}" placeholder="Separate multiple with a comma"></div>
      <div class="error-text" id="vm-error" style="display:none;"></div>
      <div class="btn-block-row" style="margin-top:6px;">
        ${!isNew ? `<button class="btn btn-outline" id="vm-delete">Delete</button>` : ''}
        <button class="btn btn-primary" id="vm-save">${isNew ? 'Add visitor' : 'Save changes'}</button>
      </div>
      ${!isNew ? `<button class="btn btn-outline" id="vm-history" style="margin-top:8px;">View visit history</button>` : ''}`;
    const root = openModal(html);
    root.querySelector('#vm-save').addEventListener('click', async () => {
      const name = root.querySelector('#vm-name').value.trim();
      if (!name) {
        const err = root.querySelector('#vm-error');
        err.textContent = 'Name is required.'; err.style.display = 'block';
        return;
      }
      item.name = name;
      item.vehicles = parseVehicles(root.querySelector('#vm-vehicles').value);
      item.isContractor = false;
      item.updatedAt = new Date().toISOString();
      if (isNew) item.createdAt = new Date().toISOString();
      await DB.put('directory', item);
      await refreshDirectory();
      closeModal();
      renderCurrentView();
      toast(isNew ? `Added "${name}" to recognised visitors.` : 'Visitor updated.');
    });
    if (!isNew) {
      root.querySelector('#vm-delete').addEventListener('click', async () => {
        if (!confirm(`Remove "${item.name}" from recognised visitors?`)) return;
        await DB.delete('directory', item.id);
        await refreshDirectory();
        closeModal();
        renderCurrentView();
        toast('Visitor removed.');
      });
      root.querySelector('#vm-history').addEventListener('click', () => { closeModal(); openVisitHistoryModal(item); });
    }
  }

  // ---------------------------------------------------------------
  // Export view + PDF report
  // ---------------------------------------------------------------
  async function renderExport() {
    const sheets = (await DB.getAll('sheets')).sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
    const list = document.getElementById('export-list');
    if (!sheets.length) { list.innerHTML = emptyState('No sheets yet', 'Start logging on the Tracker tab to create your first sheet.'); return; }
    const rows = await Promise.all(sheets.map(async s => {
      const count = (await DB.getAllByIndex('entries', 'sheetId', s.id)).length;
      return `<div class="dir-row" style="cursor:default;">
        <div class="main">
          <div class="name-line">${escapeHtml(s.date)} <span class="mono" style="font-weight:400;color:var(--muted);">${s.startTime}\u2013${s.endTime}</span></div>
          <div class="sub">${s.label ? escapeHtml(s.label) + ' \u00b7 ' : ''}${count} ${count === 1 ? 'entry' : 'entries'}</div>
        </div>
        <button class="btn btn-primary btn-sm" data-export="${s.id}">Export PDF</button>
      </div>`;
    }));
    list.innerHTML = rows.join('');
  }

  const REPORT_COLS = [
    { key: 'timeIn', label: 'IN', chars: 5 },
    { key: 'timeOut', label: 'OUT', chars: 5 },
    { key: 'name', label: 'COMPANY / REPRESENTATIVE', chars: 27 },
    { key: 'vehicle', label: 'VEHICLE REG', chars: 11 },
    { key: 'reason', label: 'REASON FOR VISIT', chars: 25 },
    { key: 'type', label: 'TYPE', chars: 4 },
    { key: 'siteContact', label: 'SITE CONTACT', chars: 16 }
  ];
  function pdfStatusLabel(st) {
    if (st.level === 'green') return 'VALID';
    if (st.level === 'gold') return 'EXPIRING SOON';
    return st.expiry ? 'EXPIRED' : 'NEEDED';
  }
  function computeColX(margin, charW, cols) {
    let x = margin; const xs = [];
    for (const c of cols) { xs.push(x); x += (c.chars + 1) * charW; }
    return xs;
  }

  function buildVisibleReport(doc, data) {
    const { sheet, entries, contractors, regularVisitors } = data;
    const margin = 40, size = 8, charW = size * 0.6;
    const colXs = computeColX(margin, charW, REPORT_COLS);
    const top = doc.H - 50, bottom = 55, rowH = 12;

    function drawColHeaders(y, cols, xs) {
      cols.forEach((c, i) => doc.text(xs[i], y, PDFLib.truncate(c.label, c.chars), { font: 'F3', size: 7.5 }));
      const last = cols[cols.length - 1];
      doc.line(margin, y - 4, xs[xs.length - 1] + last.chars * charW, y - 4, { width: 0.75 });
    }

    doc.text(margin, top, (state.settings.siteName || 'SITE OCCURRENCE SHEET').toUpperCase(), { font: 'F1', size: 14 });
    doc.text(margin, top - 16, `Date: ${sheet.date}    Shift: ${sheet.startTime}-${sheet.endTime}${sheet.label ? '  (' + sheet.label + ')' : ''}`, { font: 'F2', size: 9 });
    doc.text(margin, top - 28, `Entries: ${entries.length}    Generated: ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`, { font: 'F2', size: 7.5 });

    let y = top - 48;
    drawColHeaders(y, REPORT_COLS, colXs);
    y -= 14;

    if (!entries.length) { doc.text(margin, y, 'No entries logged for this sheet.', { font: 'F2', size: 8.5 }); y -= rowH; }

    for (const e of entries) {
      if (y < bottom) { doc.newPage(); y = doc.H - 50; drawColHeaders(y, REPORT_COLS, colXs); y -= 14; }
      REPORT_COLS.forEach((c, i) => {
        let val;
        if (c.key === 'type') val = e.type === 'contractor' ? 'CON' : 'GEN';
        else val = e[c.key] || ((c.key === 'vehicle' || c.key === 'siteContact') ? '-' : '');
        doc.text(colXs[i], y, PDFLib.truncate(String(val), c.chars), { font: 'F2', size });
      });
      y -= rowH;
    }

    doc.newPage();
    y = doc.H - 50;
    doc.text(margin, y, 'CONTRACTOR INDUCTION STATUS', { font: 'F1', size: 13 }); y -= 22;
    const ccols = [{ label: 'CONTRACTOR', chars: 28 }, { label: 'LAST INDUCTION', chars: 15 }, { label: 'VALID UNTIL', chars: 15 }, { label: 'STATUS', chars: 18 }];
    const cxs = computeColX(margin, charW, ccols);
    drawColHeaders(y, ccols, cxs); y -= 14;
    if (!contractors.length) { doc.text(margin, y, 'No contractors on file.', { font: 'F2', size: 8.5 }); y -= rowH; }
    for (const c of contractors) {
      if (y < bottom) { doc.newPage(); y = doc.H - 50; }
      const st = computeStatus(c);
      const row = [c.name, c.inductionDate || '-', st.expiry ? st.expiry.toISOString().slice(0, 10) : '-', pdfStatusLabel(st)];
      row.forEach((v, i) => doc.text(cxs[i], y, PDFLib.truncate(String(v), ccols[i].chars), { font: 'F2', size }));
      y -= rowH;
    }

    doc.newPage();
    y = doc.H - 50;
    doc.text(margin, y, 'RECOGNISED REGULAR VISITORS', { font: 'F1', size: 13 }); y -= 22;
    const vcols = [{ label: 'NAME', chars: 34 }, { label: 'VEHICLE REGISTRATION(S)', chars: 44 }];
    const vxs = computeColX(margin, charW, vcols);
    drawColHeaders(y, vcols, vxs); y -= 14;
    if (!regularVisitors.length) { doc.text(margin, y, 'No recognised visitors on file.', { font: 'F2', size: 8.5 }); y -= rowH; }
    for (const v of regularVisitors) {
      if (y < bottom) { doc.newPage(); y = doc.H - 50; }
      doc.text(vxs[0], y, PDFLib.truncate(v.name, vcols[0].chars), { font: 'F2', size });
      doc.text(vxs[1], y, PDFLib.truncate((v.vehicles || []).join(', ') || '-', vcols[1].chars), { font: 'F2', size });
      y -= rowH;
    }
  }

  async function exportSheetPDF(sheetId) {
    const sheet = await DB.get('sheets', sheetId);
    if (!sheet) return;
    const entries = (await DB.getAllByIndex('entries', 'sheetId', sheetId)).sort((a, b) => (a.timeIn || '').localeCompare(b.timeIn || ''));
    const directory = await DB.getAll('directory');
    const contractors = directory.filter(d => d.isContractor);
    const regularVisitors = directory.filter(d => !d.isContractor);

    const doc = new PDFLib.SimplePDF();
    buildVisibleReport(doc, { sheet, entries, contractors, regularVisitors });
    PDFLib.embedInvisibleData(doc, { exportedAt: new Date().toISOString(), sheet, entries, contractors, regularVisitors });

    const blob = doc.outputBlob();
    const fname = `occurrence-${sheet.date}-${sheet.startTime}-${sheet.endTime}`.replace(/:/g, '') + '.pdf';
    downloadBlob(blob, fname);
    toast('PDF exported: ' + fname);
  }

  // ---------------------------------------------------------------
  // Settings modal (site name, induction rules, JSON backup)
  // ---------------------------------------------------------------
  function openSettingsModal() {
    const s = state.settings;
    const html = `
      <button class="modal-close" data-close>&times;</button>
      <h2>Settings</h2>
      <div class="field ui-text"><label>Site name</label><input type="text" id="st-sitename" value="${escapeHtml(s.siteName || '')}" placeholder="Shown on the app header and PDF report"></div>
      <div class="row2">
        <div class="field"><label>Induction validity (months)</label><input type="number" id="st-months" value="${s.inductionValidityMonths}" min="1" max="60"></div>
        <div class="field"><label>Expiry warning (days)</label><input type="number" id="st-warn" value="${s.expiryWarningDays}" min="0" max="180"></div>
      </div>
      <button class="btn btn-primary" id="st-save">Save settings</button>
      <div class="divider"></div>
      <p class="eyebrow" style="display:block;margin-bottom:8px;">Backup</p>
      <div class="btn-block-row">
        <button class="btn btn-outline" id="st-export-json">Export JSON backup</button>
        <button class="btn btn-outline" id="st-import-json">Import backup</button>
      </div>
      <input type="file" id="st-import-file" accept="application/json" style="display:none;">
      <div class="divider"></div>
      <button class="btn btn-danger" id="st-clear">Erase all data</button>`;
    const root = openModal(html);
    root.querySelector('#st-save').addEventListener('click', async () => {
      const months = parseInt(root.querySelector('#st-months').value, 10);
      const warn = parseInt(root.querySelector('#st-warn').value, 10);
      await saveSetting('siteName', root.querySelector('#st-sitename').value.trim());
      await saveSetting('inductionValidityMonths', Number.isFinite(months) && months > 0 ? months : 12);
      await saveSetting('expiryWarningDays', Number.isFinite(warn) && warn >= 0 ? warn : 30);
      await loadSettings();
      updateHeaderSiteName();
      closeModal();
      renderCurrentView();
      toast('Settings saved.');
    });
    root.querySelector('#st-export-json').addEventListener('click', exportJSONBackup);
    root.querySelector('#st-import-json').addEventListener('click', () => root.querySelector('#st-import-file').click());
    root.querySelector('#st-import-file').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) await importJSONBackup(file);
    });
    root.querySelector('#st-clear').addEventListener('click', async () => {
      if (!confirm('This permanently erases ALL sheets, log entries, contractors and visitors from this device. Continue?')) return;
      if (!confirm('Are you absolutely sure? Consider exporting a JSON backup first.')) return;
      await DB.clear('sheets'); await DB.clear('entries'); await DB.clear('directory');
      closeModal();
      await refreshDirectory();
      state.activeSheetId = null;
      await ensureTodaySheet();
      switchView('tracker');
      toast('All data erased.');
    });
  }

  async function exportJSONBackup() {
    const data = {
      exportedAt: new Date().toISOString(),
      settings: state.settings,
      sheets: await DB.getAll('sheets'),
      entries: await DB.getAll('entries'),
      directory: await DB.getAll('directory')
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    downloadBlob(blob, `visitor-log-backup-${todayISO()}.json`);
    toast('Backup exported.');
  }

  async function importJSONBackup(file) {
    try {
      const data = JSON.parse(await file.text());
      if (!confirm('Import this backup? Existing items with matching IDs will be overwritten.')) return;
      if (Array.isArray(data.sheets)) await DB.bulkPut('sheets', data.sheets);
      if (Array.isArray(data.entries)) await DB.bulkPut('entries', data.entries);
      if (Array.isArray(data.directory)) await DB.bulkPut('directory', data.directory);
      await refreshDirectory();
      closeModal();
      renderCurrentView();
      toast('Backup imported.');
    } catch (err) {
      alert('Could not read that file as a backup: ' + err.message);
    }
  }

  // ---------------------------------------------------------------
  // Install prompt
  // ---------------------------------------------------------------
  let deferredInstallPrompt = null;
  function setupInstallPrompt() {
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if (isStandalone) return;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredInstallPrompt = e;
      document.getElementById('install-banner').classList.add('show');
    });
    document.getElementById('btn-install').addEventListener('click', async () => {
      if (!deferredInstallPrompt) return;
      deferredInstallPrompt.prompt();
      await deferredInstallPrompt.userChoice;
      deferredInstallPrompt = null;
      document.getElementById('install-banner').classList.remove('show');
    });
    window.addEventListener('appinstalled', () => document.getElementById('install-banner').classList.remove('show'));
  }

  // ---------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------
  async function init() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }

    await loadSettings();
    updateHeaderSiteName();
    await refreshDirectory();
    await ensureTodaySheet();
    document.getElementById('f-timein').value = nowTimeHHMM();

    document.querySelectorAll('.tabbar button').forEach(b => b.addEventListener('click', () => switchView(b.dataset.view)));
    document.getElementById('btn-settings').addEventListener('click', openSettingsModal);

    document.getElementById('sheet-select').addEventListener('change', async (e) => {
      state.activeSheetId = e.target.value;
      await renderTracker();
    });
    document.getElementById('btn-new-sheet').addEventListener('click', () => openSheetPeriodModal(null));
    document.getElementById('btn-edit-period').addEventListener('click', async () => {
      const sheet = await DB.get('sheets', state.activeSheetId);
      if (sheet) openSheetPeriodModal(sheet);
    });

    document.querySelectorAll('#type-toggle button').forEach(b => b.addEventListener('click', () => setEntryType(b.dataset.type)));
    setEntryType('general');

    document.getElementById('entry-form').addEventListener('submit', handleEntrySubmit);
    setupAutocomplete();

    document.getElementById('log-search').addEventListener('input', debounce(renderTracker, 150));
    document.querySelectorAll('#log-filter-chips .chip').forEach(chip => chip.addEventListener('click', () => {
      document.querySelectorAll('#log-filter-chips .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.logFilter = chip.dataset.filter;
      renderTracker();
    }));

    document.getElementById('entries-list').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const id = btn.dataset.id;
      if (btn.dataset.action === 'signout') {
        const entry = await DB.get('entries', id);
        entry.timeOut = nowTimeHHMM();
        await DB.put('entries', entry);
        await renderTracker();
        toast('Signed out at ' + entry.timeOut + '.');
      } else if (btn.dataset.action === 'edit') {
        openEditEntryModal(id);
      }
    });

    document.getElementById('btn-add-contractor').addEventListener('click', () => openContractorModal(null));
    document.getElementById('contractor-search').addEventListener('input', debounce(renderContractors, 150));
    document.getElementById('contractors-list').addEventListener('click', (e) => {
      const row = e.target.closest('.dir-row[data-id]');
      if (!row) return;
      const item = state.directory.find(d => d.id === row.dataset.id);
      if (item) openContractorModal(item);
    });

    document.getElementById('btn-add-visitor').addEventListener('click', () => openVisitorModal(null));
    document.getElementById('visitor-search').addEventListener('input', debounce(renderVisitors, 150));
    document.getElementById('visitors-list').addEventListener('click', (e) => {
      const row = e.target.closest('.dir-row[data-id]');
      if (!row) return;
      const item = state.directory.find(d => d.id === row.dataset.id);
      if (item) openVisitorModal(item);
    });

    document.getElementById('export-list').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-export]');
      if (btn) exportSheetPDF(btn.dataset.export);
    });

    setupInstallPrompt();
    switchView('tracker');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
