/* db.js — thin promise wrapper around IndexedDB.
   Stores:
     sheets     { id, date, startTime, endTime, label, createdAt }
     entries    { id, sheetId, type, name, vehicle, reason, siteContact,
                  timeIn, timeOut, directoryId, createdAt }
                  indexes: sheetId, directoryId
     directory  { id, name, vehicles:[...], isContractor, inductionDate,
                  notes, createdAt, updatedAt }
     settings   { key, value }
*/
(function (global) {
  const DB_NAME = 'siteVisitorLogDB';
  const DB_VERSION = 1;
  let dbPromise = null;

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('sheets')) {
          db.createObjectStore('sheets', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('entries')) {
          const s = db.createObjectStore('entries', { keyPath: 'id' });
          s.createIndex('sheetId', 'sheetId', { unique: false });
          s.createIndex('directoryId', 'directoryId', { unique: false });
        }
        if (!db.objectStoreNames.contains('directory')) {
          db.createObjectStore('directory', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };
      req.onsuccess = (e) => resolve(e.target.result);
      req.onerror = (e) => reject(e.target.error);
    });
    return dbPromise;
  }

  function tx(storeName, mode) {
    return openDB().then(db => db.transaction(storeName, mode).objectStore(storeName));
  }

  const DB = {
    async put(storeName, value) {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const t = db.transaction(storeName, 'readwrite');
        t.objectStore(storeName).put(value);
        t.oncomplete = () => resolve(value);
        t.onerror = () => reject(t.error);
      });
    },
    async bulkPut(storeName, values) {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const t = db.transaction(storeName, 'readwrite');
        const store = t.objectStore(storeName);
        values.forEach(v => store.put(v));
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
    },
    async get(storeName, key) {
      const store = await tx(storeName, 'readonly');
      return new Promise((resolve, reject) => {
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    },
    async getAll(storeName) {
      const store = await tx(storeName, 'readonly');
      return new Promise((resolve, reject) => {
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    },
    async getAllByIndex(storeName, indexName, value) {
      const store = await tx(storeName, 'readonly');
      return new Promise((resolve, reject) => {
        const req = store.index(indexName).getAll(value);
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    },
    async delete(storeName, key) {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const t = db.transaction(storeName, 'readwrite');
        t.objectStore(storeName).delete(key);
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
    },
    async clear(storeName) {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const t = db.transaction(storeName, 'readwrite');
        t.objectStore(storeName).clear();
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
    }
  };

  global.DB = DB;
})(typeof window !== 'undefined' ? window : globalThis);
